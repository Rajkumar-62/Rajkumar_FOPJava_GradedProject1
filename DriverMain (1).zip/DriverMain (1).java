package com.greatLearning.department.assignment;

public class DriverMain {

	public static void main(String[] args) {

		AdminDepartment admin = new AdminDepartment();
		admin.departmentName();
		admin.getTodaysWork();;
		admin.getWorkDeadline();
		admin.isTodayAHoliday();
		System.out.println();
		HrDepartment hr = new HrDepartment();
		hr.departmentName();
		hr.doActivity();
		hr.getTodaysWork();
		hr.getWorkDeadline();
		hr.isTodayAHoliday();
		System.out.println();
		TechDepartment tech = new TechDepartment();
		tech.departmentName();
		tech.getTodaysWork();
		tech.getWorkDeadline();
		tech.getTechStackInformation();
		tech.isTodayAHoliday();



	} 

}
